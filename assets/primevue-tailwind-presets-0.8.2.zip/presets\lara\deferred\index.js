export default {
    root: {}
};
