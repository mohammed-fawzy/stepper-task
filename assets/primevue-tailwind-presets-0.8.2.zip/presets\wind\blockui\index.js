export default {
    root: {
        class: 'relative'
    },
    mask: {
        class: 'bg-surface-900/60 backdrop-blur-sm'
    }
};
